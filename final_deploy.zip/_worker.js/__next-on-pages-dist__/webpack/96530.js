var n={},d=(a,c,o)=>(n.__chunk_96530=(_,r,e)=>{"use strict";e.d(r,{Z:()=>s});var t=e(20519);let s=({children:l})=>(0,t.jsx)(t.Fragment,{children:l})},n);export{d as __getNamedExports};
